package com.example.googlemaps;

import androidx.fragment.app.FragmentActivity;

import android.hardware.SensorEvent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorManager;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import static android.hardware.SensorManager.*;

public class MapsActivity<mMap, googleMap> extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private UiSettings  mUiSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        final LatLng lublin = new LatLng(51.245, 22.570);
        final CameraPosition LUBLIN = new CameraPosition.Builder().target(lublin)
                .zoom(20)
                .bearing(90)
                .tilt(60)
                .build();

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(51.245, 22.570);
        mMap.addMarker(new MarkerOptions().position(lublin).title("Marker in Lublin"));
        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(LUBLIN));
    }


    private void setUpMap() {
        final LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        final String provider = locationManager.getBestProvider(criteria, true);
        final LocationListener locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                showCurrentLocationOnMap(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                mUiSettings = mMap.getUiSettings();
                mUiSettings.setZoomControlsEnabled(true);
                mUiSettings.setCompassEnabled(true);
                mUiSettings.setMyLocationButtonEnabled(true);
                mUiSettings.setScrollGesturesEnabled(true);
                mUiSettings.setZoomGesturesEnabled(true);
                mUiSettings.setTiltGesturesEnabled(true);
                mUiSettings.setRotateGesturesEnabled(true);
            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }

            private void showCurrentLocationOnMap(Location location) {
             mMap.clear();
             LatLng currentPosition = new LatLng(location.getLatitude(),location.getLongitude());
                mMap.addMarker(new MarkerOptions()
                        .position(currentPosition)
                        .snippet(location.getLatitude() + "N" + location.getLongitude()+ "E")
                        .flat(true)
                        .title("Moja aktualna lokalizacja"));
                // zoom z dokładnością co do budynku
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentPosition,18));
            }

            public void setMapType()
            {
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
            }



            private void onSensorChanged() {
                onAccuracyChanged();
            }

            private void onAccuracyChanged() {
                onResume();
                onPause();
            }

            private void initAccelerometr()
            {
                SensorManager mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
                Sensor mSens = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                mSensorManager.registerListener(this, mSens, SensorManager.SENSOR_DELAY_GAME);
            }
            @Override
            public void onSensorChanged(SensorEvent event)
            {
                if (event.sensor.getType() == SENSOR_ACCELEROMETER){
                    float x = event.values[DATA_X];
                    float y = event.values[DATA_Y];
                    float z = event.values[DATA_Z];
                }
            }



        };

    }





}
